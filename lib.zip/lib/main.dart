import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:task_app/feature/auth/presentation/bloc/login_bloc.dart';
import 'package:task_app/feature/auth/presentation/bloc/otp_bloc.dart';
import 'package:task_app/feature/home_screen.dart';
import 'feature/auth/presentation/pages/login_page.dart';
import 'feature/auth/presentation/pages/otp_page.dart';
import 'dependency_injection.dart'as di;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await di.init() ;
  runApp(MyApp());}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers:
      [
        BlocProvider(create: (_)=> di.sl<LogInBloc>()),
        BlocProvider(create: (_)=> di.sl<OtpBloc>()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        onGenerateRoute: (settings) {
          if (settings.name == OtpPage.routeName) {
            final token = settings.arguments;

            if (token is String && token.isNotEmpty) {
              return MaterialPageRoute(
                builder: (_) => OtpPage(accessToken: token),
              );
            }
          }
          return null;
        },

        routes:
        {
          LoginPage.routeName: (_)=> LoginPage(),
          HomePage.routeName: (_)=> HomePage()
        },
      ),
    );
  }
}
