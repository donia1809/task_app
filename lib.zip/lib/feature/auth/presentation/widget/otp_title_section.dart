// import 'package:flutter/material.dart';
// import '../../../../core/theme/text_style.dart';
//
//
// class OtpTitleSection extends StatelessWidget {
//   const OtpTitleSection({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       textDirection: TextDirection.rtl,
//       children: [
//         Text(
//           'تأكيد رقم الهاتف',
//           textDirection: TextDirection.rtl,
//           style: font24weight800ColorBlue,
//         ),
//         const SizedBox(height: 4),
//         Text(
//           'لتأكيد حسابك قم بادخال الكود المكون من 4 ارقام الذي تم ارساله في رساله الي رقم الهاتف 252 --- --- --- (تغيير الرقم) , ٍسيصلك الكود خلال 01:30',
//           style: font18weight500ColorGrey,
//           textDirection: TextDirection.rtl,
//         ),
//         const SizedBox(height: 24),
//         Text(
//           'كود التأكيد',
//           textDirection: TextDirection.rtl,
//           style: font16weight500ColorBlack,
//         ),
//       ],
//     );
//   }
// }
