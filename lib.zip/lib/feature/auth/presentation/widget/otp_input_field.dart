// import 'package:flutter/material.dart';
//
// import '../../../../core/common_widget/auth_text_field.dart';
//
// class OtpTextFields extends StatelessWidget {
//   final List<TextEditingController> otpControllers;
//
//   const OtpTextFields({super.key, required this.otpControllers});
//
//   @override
//   Widget build(BuildContext context) {
//     return SizedBox(
//       height: 100,
//       child: GridView.builder(
//         physics: const NeverScrollableScrollPhysics(),
//         gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//           crossAxisCount: 4,
//           mainAxisSpacing: 16,
//           crossAxisSpacing: 16,
//         ),
//         itemCount: 4,
//         itemBuilder: (context, index) {
//           return AspectRatio(
//             aspectRatio: 1,
//             child: AuthTextField(
//               isOtp: true,
//             controller: otpControllers[index],),
//           );
//         },
//       ),
//     );
//   }
// }
