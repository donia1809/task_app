// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:task_app/core/theme/colors.dart';
// import 'package:task_app/feature/auth/presentation/bloc/otp_bloc.dart';
// import '../../../../core/common_widget/auth_button.dart';
// import '../../../../core/theme/text_style.dart';
//
//
// class OtpActionsSection extends StatelessWidget {
//   const OtpActionsSection({super.key, required this.otpControllers, required this.accessToken});
//   final List<TextEditingController> otpControllers;
//   final String accessToken;
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         AuthButton(
//           text: 'تأكيد',
//         onPressed: () {
//           final otp = otpControllers.map((c) => c.text.trim()).join();
//           if (otp.isNotEmpty && otp.length == 4) {
//             BlocProvider.of<OtpBloc>(context)
//                 .add(VerifyOtpEvent(otp: otp, accessToken: accessToken));
//           } else {
//             ScaffoldMessenger.of(context).showSnackBar(
//               const SnackBar(content: Text('الرجاء إدخال كود otp كامل')),
//             );
//           }
//         },
//           backgroundColor: AppColors.primaryColor,
//           textColor: AppColors.white,
//         ),
//         const SizedBox(height: 8),
//         Row(
//           textDirection: TextDirection.rtl,
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Text('لم تصلك رسالة تأكيد؟', style: font14weight400ColorBlack),
//             SizedBox(width: 8),
//             Text('اعادة ارسال الكود', style: font14weight800ColorBlue),
//           ],
//         ),
//       ],
//     );
//   }
// }
