// import 'package:dartz/dartz.dart';
// import 'package:task_app/core/error/failure.dart';
// import 'package:task_app/feature/city/domain/entity/city_entity.dart';
// import 'package:task_app/feature/city/domain/repo/city_repo.dart';
// import '../../../../../core/error/exceptions.dart';
// import '../data_source/city_remote_data_source.dart';
//
//
// class CityRepoImpl extends CityRepo
// {//object from data source
//   final CityRemoteDataSource cityRemoteDataSource;
//
//   CityRepoImpl({required this.cityRemoteDataSource});
//
//   @override
//   Future<Either<Failure, CityEntity>> verifyOtp(String otp, String accessToken) async {
//     try {
//       final result = await cityRemoteDataSource.verifyOtp(otp, accessToken);
//       return Right(result);
//     } on UnAuthorizedException {
//       return Left(UnAuthorizedFailure());
//     } on ServerException {
//       return Left(ServerFailure());
//     } on NetworkException {
//       return Left(NetworkFailure());
//     } catch (e) {
//       return Left(ServerFailure());
//     }
//   }
// }
//
