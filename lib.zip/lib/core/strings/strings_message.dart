const String LOGIN_SUCCESS_MESSAGE = "Login request sent successfully";
const String OTP_SUCCESS_MESSAGE = "OTP verified successfully";
