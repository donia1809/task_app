class ApiConstants {
  static const baseUrl = "https://backend.seed.moltaqadev.com/client-api/v1/auth";
  static const apiKey = "YOUR_API_KEY";
  static const apiVersion = "v1";
}
